package cpsc2150.ConnectX;

public class GameBoard {
    static char[][] board = new char[6][7];

    public static boolean checkIfFree(int c){
        if(empty(5, c)) {
            return true;
        }
        else{return false;}
    }

    public static boolean checkForWin(int c){
        int i = 5;
        int row = 0;
        while(i > 0) { //trying to find the last element placed in this column
            if (/*board[i][c].*/empty(5, c)) {
                i--;
            }
            else{
                row = i;
                i = 0;
            }
        }
        int last = board[i][c];
        char player = whatsAtPos(i, c);

        if(checkHorizWin(row, c, player)){
            return true;
        }
        else if(checkVertWin(row, c, player)){
            return true;
        }
        else if(checkDiagWin(row, c, player)){
            return true;
        }
        else{return false;}
    }

    public static void placeToken(char p, int c){
        for(int i = 0; i < 7; i++){
            if(checkIfFree(c)){
                board[i][c] = p;
                break;
            }
        }
    }

    public static boolean checkHorizWin(int r, int c, char p){
        //for(int count = 1; count < 4; c--) {
        int count = 1;
        int var = c;
        if(p == 'X' || p == 'O') {
            while (var >= 0) {
                if (var != 0) {
                    if (/*whatsAtPos(r, c - 1)*/ board[r][var - 1] == p) { //check to the left
                        count++;
                        //checkHorizWin(r, c - 1, p);
                    }
                }
                if (count == 4) {
                    return true;
                }
                var--;
            }
            while (var < 7) {
                if (var != 6) {
                    if (/*whatsAtPos(r, c + 1)*/ board[r][var + 1] == p) { //check to the right
                        count++;
                        //checkHorizWin(r, c + 1, p);
                    }
                }
                if (count == 4) {
                    return true;
                }
                var++;
            }
        }
        return false;
    }

    public static boolean checkVertWin(int r, int c, char p){
        if(p == 'X' || p == 'O') {
            for (int count = 1; count < 4; r--) {
                if (board[r - 1][c] == p) { //check below
                    count++;
                }
                if (count == 4) {
                    return true;
                }
            }
            for (int count = 1; count < 4; r++) {
                if (board[r + 1][c] == p) { //check above
                    count++;
                }
                if (count == 4) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean checkDiagWin(int r, int c, char p){
        int count = 1;
        if(p == 'X' || p == 'O') {
            if (whatsAtPos(r - 1, c - 1) == p) {
                count++;
                checkDiagWin(r - 1, c - 1, p);
                if (count == 4) {
                    return true;
                }
            } else if (whatsAtPos(r + 1, c - 1) == p) {
                count++;
                checkDiagWin(r + 1, c - 1, p);
                if (count == 4) {
                    return true;
                }
            } else if (whatsAtPos(r + 1, c + 1) == p) {
                count++;
                checkDiagWin(r + 1, c + 1, p);
                if (count == 4) {
                    return true;
                }
            } else if (whatsAtPos(r - 1, c + 1) == p) {
                count++;
                checkDiagWin(r - 1, c + 1, p);
                if (count == 4) {
                    return true;
                }
            }
        }
        return false;
    }

    public static char whatsAtPos(int r, int c){return board[r][c];}

    /**
     * @Override toString
     * @return the gameboard in string format
     */
    public String toString(){ //prints the gameboard
        String str = new String ("|0|1|2|3|4|5|6|\n") ;

        for(int r = 5; r >= 0; r--){
            for(int c = 0; c < 7; c++) {
                //System.out.print("|" + whatsAtPos(r, c));
                str = str + "|" + whatsAtPos(r, c);
            }
            str = str + "|\n";
        }
        return str;
    }

    public static boolean checkTie(){
        for(int c = 0; c < 8; c++) {
            if (!checkIfFree(c) && !checkForWin(c)){
                return true;
            }
        }
        return false;
    }

    public GameBoard(){
        for(int r = 0; r < 6; r++) {
            for (int c = 0; c < 7; c++) {
                board[r][c] = ' ';
            }
        }
    }

    private static boolean empty(int r, int c){
        if(whatsAtPos(r, c) == ' '){
            return true;
        }
        else{return false;}
    }
}
