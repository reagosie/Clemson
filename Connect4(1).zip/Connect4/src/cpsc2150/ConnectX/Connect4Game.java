package cpsc2150.ConnectX;

import java.util.*;

public class Connect4Game extends GameBoard {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        GameBoard board = new GameBoard();
        char x = 'X';
        char o = 'O';
        int c = 0;
        int turn = 2;
        boolean gameover = false;

        while (!gameover) {
            System.out.println(board);
            if (turn % 2 == 0) {
                System.out.println("Player X, what column do you want to place your marker in?");
                int choice = scan.nextInt();
                if (checkIfFree(choice)) {
                    placeToken(x, choice);
                }
                turn++;
            } else if (turn % 2 == 1) {
                System.out.println("Player O, what column do you want to place your marker in?");
                int choice = scan.nextInt();
                if (checkIfFree(choice)) {
                    placeToken(o, choice);
                }
                turn++;
            }
            if (checkForWin(c)) {
                gameover = true;
                System.out.println("Player " + x + " won!\nWould you like to play again? Y/N\n");
                String choice = scan.nextLine();
                String no = "N";
                if (choice == no) {
                    return;
                }
            }
            if (checkTie()) {
                gameover = true;
                System.out.println("It's a tie!\nWould you like to play again? Y/N\n");
                String choice = scan.nextLine();
                String no = "N";
                if (choice == no) {
                    return;
                }
            }
            System.out.println(board);
        }
    }
}

