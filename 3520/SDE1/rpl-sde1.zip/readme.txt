REAGAN LEONARD README.TXT
CPSC 3520
SDE1
FEB 20, 2020

Pledge:
On my honor I have neither given nor received aid on this exam.

Contents of zip archive:
-This readme.txt file
-My source code file (sde1_sp2020.caml)
    -This file includes the functions defined in Section 6 of the assignment PDF, as well as all
      helper functions that I designed and implemented to complete the project.
    -These functions include:
        -createList (helper)
        -addList (helper)
        -nextState
        -updateN
        -createMatrix (helper)
        -addMatrix (helper)
        -addWeights (helper)
        -hopTrainAstate
        -hopTrain
        -findsEquilibrium
        -getListSize (helper)
        -energy
-The ASCII log file (sde1.log)
    -this file shows at least 2 sample uses of each of the functions required in Section 6 of the assignment PDF.
