REAGAN LEONARD README.TXT
CPSC 3520
SDE2
APR 9, 2020

Pledge:
On my honor I have neither given nor received aid on this exam.
SIGN Reagan Leonard

Contents of zip archive:
-This readme.txt file
-My source code file (sde2_sp2020.pro)
    -This file includes the predicates defined in Section 5 of the assignment PDF, as well as all
      helper predicates that I designed and implemented to complete the project.
    -These functions include:
        -nextState
        -updateN
        -findsEquilibrium
        -energy
        -checkHead (helper)
        -hopHelper (helper)
        -createWeight (helper)
        -hopTrainAstate
        -addList (helper)
        -addMatrix (helper)
        -hopTrain
        -xMinusOne (helper)
        -add (helper)
-The ASCII log file (sde2.log)
    -this file contains data used in test cases
    -this file also shows 2 sample uses of each of the predicates required in Section 5 of the assignment PDF
        -MY output for each test case is shown beneath the test case in a Prolog comment (/* */) and was pasted directly from my terminal
    -Note: this file also shows 2 sample uses of the given predicates hop11Activation and netUnit
    -Note: I also completed every test case provided in the PDF (and they were all successful)
