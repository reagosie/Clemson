package cpsc2150.lab2;

public class MatrixApp {
    public static void main(String [] args){
        System.out.println("How many rows should your matrix have?\n");
        
    }
}
