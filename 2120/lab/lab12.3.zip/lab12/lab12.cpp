#include "dna_alignment.h"

// Call process in dna_alignment
int main(int argc, char* argv[]){
  DNA dna;
  dna.process();
}
