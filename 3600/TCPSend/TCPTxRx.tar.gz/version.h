/************************************************************************
* File:  version.h
*
* Purpose:
*   To track a programs version.
*
************************************************************************/
#ifndef	__version_h
#define	__version_h

#define VersionLevel 1.0


#endif


